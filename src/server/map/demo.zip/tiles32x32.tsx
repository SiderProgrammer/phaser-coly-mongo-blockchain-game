<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="tiles32x32" tilewidth="32" tileheight="32" tilecount="304" columns="19">
 <image source="tiles32x32.png" width="608" height="512"/>
</tileset>
