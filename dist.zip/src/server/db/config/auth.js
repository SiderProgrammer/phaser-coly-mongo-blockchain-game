const USERNAME = "game0001";
const PASSWORD = "4WaFcM6RUAju1HMC";
const HOST = "game01.qybxp.mongodb.net";
//const DB = "UpworkProjectDB";

module.exports = { USERNAME, PASSWORD, HOST };
