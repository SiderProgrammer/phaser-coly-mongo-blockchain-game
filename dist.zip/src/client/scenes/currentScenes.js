export const WORLD_SCENE = {
  SCENE: {},
  setScene: function (scene) {
    this.SCENE = scene;
  },
};
export const CHALLENGE_SCENE = {
  SCENE: {},
  setScene: function (scene) {
    this.SCENE = scene;
  },
};

export const HUD_SCENE = {
  SCENE: {},
  setScene: function (scene) {
    this.SCENE = scene;
  },
};

export const GUI_SCENE = {
  SCENE: {},
  setScene: function (scene) {
    this.SCENE = scene;
  },
};
